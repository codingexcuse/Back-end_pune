package com.example.wholesaler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WholesalerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WholesalerApplication.class, args);
	}

}
