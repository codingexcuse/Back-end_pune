package com.example.wholesaler.controller;

import com.example.wholesaler.entity.Wholesaler;
import com.example.wholesaler.repository.WholesalerRepository;
import com.example.wholesaler.service.WholesalerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

//import static sun.security.ssl.SSLLogger.property;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/wholesaler")
public class WholesalerController {
    @Autowired
    private  WholesalerRepository wholesalerRepository;
    @Autowired
    private WholesalerService wholesalerService;


    @CrossOrigin(origins = "*")
    @PostMapping("/create")
    public ResponseEntity<String> createWholesaler(@Valid @RequestBody Wholesaler wholesaler){
        Optional<Wholesaler> wholesalerlocid= wholesalerRepository.findBylocid(wholesaler.getLocId());
        Optional<Wholesaler> wholesaleremail= wholesalerRepository.findByemail(wholesaler.getEmail());
        Optional<Wholesaler> wholesalerphone= wholesalerRepository.findByphoneNumber(wholesaler.getPhoneNumber());
        Optional<Wholesaler> wholesalerId= wholesalerRepository.findBywholesalerId(wholesaler.getWholesalerId());
        //IdValidator idValidator = new IdValidator();
        if(!IdValidator.isValidId(wholesaler.getWholesalerId())){
            throw new IllegalStateException("wholesalerid is not appropriate");
        }
        if(wholesalerlocid.isPresent())
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("WholesalerLocId already exist");

        }
        if(wholesalerphone.isPresent())
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Wholesalers Phone Number already exist");

        }
        if(wholesalerId.isPresent())
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("WholesalerId already exist");

        }
        if(wholesaleremail.isPresent())
        {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("WholesalerEmail already exist");

        }
        Wholesaler wholesaler1 = wholesalerRepository.save(wholesaler);
        return ResponseEntity.ok("Successfully added");

//
    }
    @CrossOrigin(origins = "*")
    @DeleteMapping("/delete/{id}")
    public void deleteWholesaler(@PathVariable("id") long id){
        wholesalerRepository.deleteById(id);
    }
    @CrossOrigin(origins = "*")
    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateWholesaler(@PathVariable("id") long id, @RequestBody Wholesaler wholesaler){

        Optional<Wholesaler> wholesalerOptional= wholesalerRepository.findById(id);
        Optional<Wholesaler> wholesalerlocid= wholesalerRepository.findBylocid(wholesaler.getLocId());
        Optional<Wholesaler> wholesaleremail= wholesalerRepository.findByemail(wholesaler.getEmail());
        Optional<Wholesaler> wholesalerphone= wholesalerRepository.findByphoneNumber(wholesaler.getPhoneNumber());
        Optional<Wholesaler> wholesalerId= wholesalerRepository.findBywholesalerId(wholesaler.getWholesalerId());

       // IdValidator idValidator = new IdValidator();
        String s;
        Wholesaler wholesaler1 = wholesalerOptional.get();
        if(wholesalerOptional.isPresent()) {
            if (!IdValidator.isValidId(wholesaler.getWholesalerId())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("wholesalerid is not appropriate");
            }
            if (wholesalerlocid.isPresent() ) {
                if (wholesalerlocid.get().getId() != wholesalerOptional.get().getId()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("WholesalerLocId already exist");
                }
            }
            if (wholesalerphone.isPresent() ) {
                if(wholesalerphone.get().getId() != wholesalerOptional.get().getId()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Wholesalers Phone Number already exist");
                }
            }
            if (wholesalerId.isPresent() ) {
                if ( wholesalerId.get().getId() != wholesalerOptional.get().getId()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("WholesalerId already exist");
                }
            }
            if (wholesaleremail.isPresent() ) {
                if (wholesaleremail.get().getId() != wholesalerOptional.get().getId()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("WholesalerEmail already exist");
                }
            }
            else {
                wholesaler1.setFirstName(wholesaler.getFirstName());
                wholesaler1.setLastName(wholesaler.getLastName());
                wholesaler1.setEmail(wholesaler.getEmail());
                wholesaler1.setPhoneNumber(wholesaler.getPhoneNumber());
                wholesaler1.setWholesalerId(wholesaler.getWholesalerId());
                wholesaler1.setRole(wholesaler.getRole());
                wholesaler1.setLocId(wholesaler.getLocId());
                wholesalerRepository.save(wholesaler1);
                return ResponseEntity.ok("Updated");
            }

        }

         return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("this id is not present");
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/get")
    public List<Wholesaler> getWholesaler(){
        return wholesalerRepository.findAllByOrderByIdDesc();

    }

    @GetMapping("/get/sortedbyfirstname")
    public List<Wholesaler> getsortedbyfirstname(){
        List<Wholesaler> myList = wholesalerRepository.findAll();
        List<Wholesaler> sortedList = myList.stream()
                .sorted(Comparator.comparing(Wholesaler::getFirstName))
                .collect(Collectors.toList());
        return sortedList;
    }
    @CrossOrigin(origins = "*")
    @GetMapping("/filter")
    public List<Wholesaler> filter(@RequestBody Wholesaler wholesaler){


        List<Wholesaler> firstNamefilter = new ArrayList<>();
        firstNamefilter=wholesalerService.filter(wholesaler.getFirstName());

        List<Wholesaler> lastNamefilter = new ArrayList<>();
        lastNamefilter=wholesalerService.filter(wholesaler.getLastName());

        List<Wholesaler> emailfilter = new ArrayList<>();
        emailfilter=wholesalerService.filter(wholesaler.getEmail());

        List<Wholesaler> phoneNumberfilter = new ArrayList<>();
        phoneNumberfilter=wholesalerService.filter(Long.toString(wholesaler.getPhoneNumber()));

        List<Wholesaler> wholesalerIdfilter = new ArrayList<>();
        wholesalerIdfilter=wholesalerService.filter(wholesaler.getWholesalerId());

        firstNamefilter.retainAll(lastNamefilter);
        firstNamefilter.retainAll(emailfilter);
        firstNamefilter.retainAll(phoneNumberfilter);
        firstNamefilter.retainAll(wholesalerIdfilter);
        return firstNamefilter;
      }
//      @GetMapping("/filtere")
//      public List<Wholesaler> getWholesalers(Wholesaler wholesaler) {
//          // logic to fetch and filter wholesalers based on the parameters
//          String firstName= wholesaler.getFirstName();
//          String lastName= wholesaler.getLastName();
//          String email= wholesaler.getEmail();
//          String wholesalerId= wholesaler.getWholesalerId();
//          long phoneNumber= wholesaler.getPhoneNumber();
//          List<Wholesaler> filteredWholesalers = wholesalerRepository.findByfirstNameAndlastNameAndemailAndwholesalerIdAndphoneNumber(firstName, lastName, email, wholesalerId, phoneNumber);
//          // fetch and filter logic here
//
//          return filteredWholesalers;
//      }

}
