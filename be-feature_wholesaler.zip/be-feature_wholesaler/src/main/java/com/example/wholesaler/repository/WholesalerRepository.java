package com.example.wholesaler.repository;

import com.example.wholesaler.entity.Wholesaler;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface WholesalerRepository extends JpaRepository<Wholesaler, Long> {
    List<Wholesaler> findAllByOrderByIdDesc();

    Optional<Wholesaler> findBylocid(@Param("locid") String locid);

    Optional<Wholesaler> findByemail(String email);

    Optional<Wholesaler> findByphoneNumber(long phoneNumber);

    Optional<Wholesaler> findBywholesalerId(String wholesalerId);

    //List<Wholesaler> findByfirstNameAndlastNameAndemailAndwholesalerIdAndphoneNumber(String firstName, String lastName, String email, String wholesalerId, long phoneNumber);

    // List<Wholesaler> findAllOrderByfirstNameAsc();
}
