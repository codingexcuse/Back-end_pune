package com.example.wholesaler.entity;

import jakarta.persistence.*;
import lombok.Value;
import org.intellij.lang.annotations.Pattern;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

@Entity
@Table(name = "wholesaler")
public class Wholesaler {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id", nullable = false)
    private Long id;

    private String firstName;
    private String lastName;
    private String email;
    private long phoneNumber;
    @Pattern("^(?=.*[0-9])(?=.*[A-Za-z])[A-Za-z0-9]{6}$")
    private String wholesalerId;
    private String role;

    private String locid;

    public Wholesaler() {
    }

    public Wholesaler(Long id, String firstName, String lastName, String email, long phoneNumber, String wholesalerId, String role, String locid) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.wholesalerId = wholesalerId;
        this.role = role;
        this.locid = locid;
    }

    public Wholesaler(String firstName, String lastName, String email, long phoneNumber, String wholesalerId, String role, String locid) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.wholesalerId = wholesalerId;
        this.role = role;
        this.locid= locid;
    }

    public Wholesaler(String firstName, String lastName, String email, long phoneNumber, String wholesalerId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.wholesalerId = wholesalerId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getWholesalerId() {
        return wholesalerId;
    }

    public void setWholesalerId(String wholesalerId) {
        this.wholesalerId = wholesalerId;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getLocId() {
        return locid;
    }

    public void setLocId(String locid) {
        this.locid = locid;
    }

}
