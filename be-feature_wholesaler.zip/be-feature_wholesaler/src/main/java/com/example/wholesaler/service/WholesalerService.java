package com.example.wholesaler.service;

import com.example.wholesaler.entity.Wholesaler;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
@Service
public class WholesalerService {

//    public List<Wholesaler> getWholesalerIdFilter(@RequestParam("wholesalerId") String wholesalerId) {
//        List<Wholesaler> wholesalers = new ArrayList<>();
//        List<Wholesaler> filteredWholesalers = new ArrayList<>();
//        for (Wholesaler wholesaler : wholesalers) {
//            wholesalerId = StringUtils.trimAllWhitespace(wholesalerId);
//            if (wholesaler.getWholesalerId().toLowerCase().startsWith(wholesalerId.toLowerCase())) {
//                filteredWholesalers.add(wholesaler);
//            }
//        }
//        return filteredWholesalers;
//    }
//
//    public List<Wholesaler> getPhoneNumberFilter(@RequestParam("phoneNumber") long phoneNumber) {
//        List<Wholesaler> wholesalers = new ArrayList<>();
//        List<Wholesaler> filteredWholesalers = new ArrayList<>();
//        for (Wholesaler wholesaler : wholesalers) {
//            String phone = Long.toString(phoneNumber);
//            phoneNumber = Long.parseLong(StringUtils.trimAllWhitespace(String.valueOf(phoneNumber)));
//            if (Long.toString(wholesaler.getPhoneNumber()).toLowerCase().startsWith(phone.toLowerCase())) {
//                filteredWholesalers.add(wholesaler);
//            }
//        }
//        return filteredWholesalers;
//    }
//
//    public List<Wholesaler> getFirstNameFilter(@RequestParam("firstName") String firstName) {
//        List<Wholesaler> wholesalers = new ArrayList<>();
//        List<Wholesaler> filteredWholesalers = new ArrayList<>();
//        for (Wholesaler wholesaler : wholesalers) {
//            firstName = StringUtils.trimAllWhitespace(firstName);
//            if (wholesaler.getFirstName().toLowerCase().startsWith(firstName.toLowerCase())) {
//                filteredWholesalers.add(wholesaler);
//            }
//        }
//        return filteredWholesalers;
//
//    }
//
//    public List<Wholesaler> getLastNameFilter(@RequestParam("lastName") String lastName) {
//        List<Wholesaler> wholesalers = new ArrayList<>();
//        List<Wholesaler> filteredWholesalers = new ArrayList<>();
//        for (Wholesaler wholesaler : wholesalers) {
//            lastName = StringUtils.trimAllWhitespace(lastName);
//            if (wholesaler.getLastName().toLowerCase().startsWith(lastName.toLowerCase())) {
//                filteredWholesalers.add(wholesaler);
//            }
//        }
//        return filteredWholesalers;
//    }
//
//    public List<Wholesaler> getEmailFilter(@RequestParam("email") String email) {
//        List<Wholesaler> wholesalers = new ArrayList<>();
//        List<Wholesaler> filteredWholesalers = new ArrayList<>();
//        for (Wholesaler wholesaler : wholesalers) {
//            email = StringUtils.trimAllWhitespace(email);
//            if (wholesaler.getEmail().toLowerCase().startsWith(email.toLowerCase())) {
//                filteredWholesalers.add(wholesaler);
//            }
//        }
//        return filteredWholesalers;
//    }

    public List<Wholesaler> filter(String name) {
        switch (name) {
            case "firstName": {
                List<Wholesaler> wholesalers = new ArrayList<>();
                List<Wholesaler> filteredWholesalers = new ArrayList<>();
                for (Wholesaler wholesaler : wholesalers) {
                    //wholesaler.setFirstName();
                    String firstName = StringUtils.trimAllWhitespace(wholesaler.getFirstName());
                    if (wholesaler.getFirstName().toLowerCase().startsWith(firstName.toLowerCase())) {
                        filteredWholesalers.add(wholesaler);
                    }
                }
                return filteredWholesalers;
            }

            case "lastName":
                {
                    List<Wholesaler> wholesalers = new ArrayList<>();
                    List<Wholesaler> filteredWholesalers = new ArrayList<>();
                    for (Wholesaler wholesaler : wholesalers) {
                       // wholesaler.setLastName(StringUtils.trimAllWhitespace(wholesaler.getLastName()));
                        String lastName=StringUtils.trimAllWhitespace(wholesaler.getLastName());
                        if (wholesaler.getLastName().toLowerCase().startsWith(wholesaler.getLastName().toLowerCase())) {
                            filteredWholesalers.add(wholesaler);
                        }
                    }
                    return filteredWholesalers;
                }

            case "email":
                {
                    List<Wholesaler> wholesalers = new ArrayList<>();
                    List<Wholesaler> filteredWholesalers = new ArrayList<>();
                    for (Wholesaler wholesaler : wholesalers) {
                        //email = StringUtils.trimAllWhitespace(email);
                        String email =StringUtils.trimAllWhitespace(wholesaler.getEmail());
                        if (wholesaler.getEmail().toLowerCase().startsWith(email.toLowerCase())) {
                            filteredWholesalers.add(wholesaler);
                        }
                    }
                    return filteredWholesalers;
                }


            case "phoneNumber":
                {
                    List<Wholesaler> wholesalers = new ArrayList<>();
                    List<Wholesaler> filteredWholesalers = new ArrayList<>();
                    for (Wholesaler wholesaler : wholesalers) {
                       String phone = Long.toString(wholesaler.getPhoneNumber());

                        phone = StringUtils.trimAllWhitespace(String.valueOf(phone));
                        if (Long.toString(wholesaler.getPhoneNumber()).toLowerCase().startsWith(phone.toLowerCase())) {
                            filteredWholesalers.add(wholesaler);
                        }
                    }
                    return filteredWholesalers;
                }

            case "wholesalerId":
                {
                    List<Wholesaler> wholesalers = new ArrayList<>();
                    List<Wholesaler> filteredWholesalers = new ArrayList<>();
                    for (Wholesaler wholesaler : wholesalers) {
                        String wholesalerId = StringUtils.trimAllWhitespace(wholesaler.getWholesalerId());
                        if (wholesaler.getWholesalerId().toLowerCase().startsWith(wholesalerId.toLowerCase())) {
                            filteredWholesalers.add(wholesaler);
                        }
                    }
                    return filteredWholesalers;
                }



        }

        return null;
    }
}

