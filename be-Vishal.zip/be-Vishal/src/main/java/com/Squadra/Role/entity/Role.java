package com.Squadra.Role.entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table
@Getter
@Setter
@NoArgsConstructor
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String roleName;
    private String orgName;
    private Date createdDate;
    private Boolean roleState;
    private String roleId;

    public Role(String roleName, String orgName, Date createdDate, Boolean roleState, String roleId) {
        this.roleName = roleName;
        this.orgName = orgName;
        this.createdDate = createdDate;
        this.roleState = roleState;
        this.roleId = roleId;
    }
    @Override
    public String toString() {
        return "Role{" +
                "roleName='" + roleName + '\'' +
                ", orgName='" + orgName + '\'' +
                ", createdDate=" + createdDate +
                ", roleState=" + roleState +
                ", roleId='" + roleId + '\'' +
                '}';
    }
}

