package com.Squadra.Role.controller;

import com.Squadra.Role.Request.RoleRequest;
import com.Squadra.Role.entity.Role;
import com.Squadra.Role.repository.RoleRepository;
import com.Squadra.Role.service.RoleService;
import com.Squadra.Role.specification.RoleSpecification;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.bohnman.squiggly.Squiggly;
import com.github.bohnman.squiggly.util.SquigglyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import javax.management.relation.RoleNotFoundException;
import javax.validation.Valid;
import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping(path = "api/v1/role")
@Transactional
public class RoleController {

    private static final String DEFAULT_GRAPHQL = "roleId,roleName,orgName,roleState,createdDate";
    @Autowired
    private RoleService roleService;

    @Autowired
    private final  RoleRepository roleRepository;

    public RoleController(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @CrossOrigin(origins = "*")
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> showRoles()
    {
    List<Role> roles = roleService.getRole();
    return ResponseEntity.status(HttpStatus.OK).body(SquigglyUtils.stringify(Squiggly.init(new ObjectMapper(), DEFAULT_GRAPHQL), roles));
    }

    @CrossOrigin(origins = "*")
    @PostMapping(value = "/addrole",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> registerNewRole(@RequestBody @Valid RoleRequest roleRequest)
    {
        try {
            roleService.addNewRole(roleRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body("Role Added Successfully");
        } catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add role.");
        }

    }

    @CrossOrigin(origins = "*")
    @PutMapping("/editrole/{RoleId}")
    public ResponseEntity<String> updateRole(@PathVariable("RoleId") String RoleId,@RequestBody Role role)
    {
        try {
            roleService.updateRole(RoleId,role);
            return ResponseEntity.ok().body("Role with Roleid - "+ RoleId+" updated");
        } catch (Exception e)
        {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update role.");
        }

    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/delrole/{RoleId}")
    public String deleteRole(@PathVariable("RoleId") String RoleId) throws RoleNotFoundException {
        roleService.deleteRole(RoleId);

        return "DELETED Role with Roleid - "+ RoleId;
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/sort")
    public List<Role> getSortedRoles(@RequestParam("field") String field, @RequestParam("direction") String direction) {
        Sort.Direction sortDirection = Sort.Direction.ASC;
        if (direction.equalsIgnoreCase("desc")) {
            sortDirection = Sort.Direction.DESC;

        }
        return roleService.findRoleWithSorting(field, sortDirection);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/pagination/{offset}/{pageSize}")
    public Page<Role> getRoleWithPagination(
            @PathVariable int offset,@PathVariable int pageSize)
    {
        return roleService.findRoleWithPagination(offset,pageSize);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/filtered")
    public List<Role> roleFilter(@RequestParam(required = false) String roleName, @RequestParam(required = false) String roleId,
                                  @RequestParam(required = false) String orgName, @RequestParam(required = false) Boolean roleState,
                                  @RequestParam(required = false) Date createdDate) {
        Role filter = new Role();
        filter.setRoleName(roleName);
        filter.setRoleId(roleId);
        filter.setRoleState(roleState);
        filter.setOrgName(orgName);
        filter.setCreatedDate(createdDate);

        RoleSpecification spec = new RoleSpecification(filter);
        if (!spec.isValid()) {
            throw new IllegalArgumentException(spec.getErrorMessage());
        }
//        Specification<Role> spec = new RoleSpecification(filter);

        return roleRepository.findAll(spec);
    }

//    @PostMapping(path = "/roles/page", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
//    public ResponseEntity page(@RequestBody PageRequest request) {
//        String graphql = request.getGraphql() == null ? DEFAULT_GRAPHQL : request.getGraphql();
//        PageWrapper response = roleService.processPageRequest(request);
//        String pageGraphQl = "content[" + graphql + "],last,totalPages,totalElements,size,number,sort,first,numberOfElements";
//        return ResponseEntity.ok(SquigglyUtils.stringify(Squiggly.init(new ObjectMapper(), pageGraphQl), response));
//    }

}
