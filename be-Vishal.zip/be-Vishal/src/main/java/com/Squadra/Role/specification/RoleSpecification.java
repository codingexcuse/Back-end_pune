package com.Squadra.Role.specification;

import com.Squadra.Role.entity.Role;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

public class RoleSpecification implements Specification<Role> {

    private final  Role role;

    public RoleSpecification( Role role)
    {

        this.role = role;
    }
    @Override
    public Predicate toPredicate(Root<Role> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();

        if (role.getRoleName() != null) {
            String roleName = "%" + role.getRoleName().toLowerCase() + "%";
            predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("roleName")), roleName));
        }

        if (role.getRoleId() != null) {
            String roleId = "%" + role.getRoleId().toLowerCase() + "%";
            predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("roleId")), roleId));
        }

        if (role.getOrgName() != null) {
            String orgName = "%" + role.getOrgName().toLowerCase() + "%";
            predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("orgName")), orgName));
        }

        if (role.getCreatedDate()!= null)
        {
            predicates.add(criteriaBuilder.equal(root.get("createdDate"),role.getCreatedDate()));
        }

        if (role.getRoleState()!= null)
        {
            predicates.add(criteriaBuilder.equal(root.get("roleState"),role.getRoleState()));
        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }

    public boolean isValid() {
        return (role.getRoleName() != null && !role.getRoleName().isEmpty())
                || (role.getRoleId() != null && !role.getRoleId().isEmpty())
                || (role.getOrgName() != null && !role.getOrgName().isEmpty())
                || role.getRoleState() != null
                || role.getCreatedDate() != null;
    }

    public String getErrorMessage() {
        return "At least one filter criteria must be provided";
    }
}
