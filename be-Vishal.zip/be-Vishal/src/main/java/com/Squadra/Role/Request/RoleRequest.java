package com.Squadra.Role.Request;
import lombok.Getter;
import lombok.Setter;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.time.LocalDate;

@Getter
@Setter
public class RoleRequest {

    @NotNull
    @NotBlank(message = "RoleName is required")
    @Pattern(regexp = "^[a-zA-Z_ ]+$",message = "RoleName must Not be Alphanumeric")
    private String roleName;

    @NotNull
    @NotBlank(message = "OrgName is required")
    private String orgName;

    private LocalDate createdDate;

    @NotNull
    private Boolean roleState;

    @NotNull
    @NotBlank(message = "RoleId is required")
     @Pattern(regexp = "^[A-Z]{3}[0-9]{3}$", message = "RoleId must be alphanumeric and of 6 characters (3 Capital alphabets and 3 numbers)")
    private String roleId;

    public RoleRequest() {
        this.createdDate = LocalDate.now();
        this.roleState = true;
    }
}
