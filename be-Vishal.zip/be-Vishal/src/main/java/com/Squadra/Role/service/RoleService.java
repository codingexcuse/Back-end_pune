package com.Squadra.Role.service;

import com.Squadra.Role.Request.RoleRequest;
import com.Squadra.Role.entity.Role;
import com.Squadra.Role.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.management.relation.RoleNotFoundException;
import javax.validation.Valid;
import java.sql.Date;
import java.util.List;
import java.util.Optional;

@Service
public class RoleService {

    private final RoleRepository roleRepository;

    @Autowired
    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public List<Role> getRole() {
        return roleRepository.findAllByOrderByIdDesc();
    }

    public void addNewRole(@Valid RoleRequest request) {
        Optional<Role> RoleOptional = roleRepository.findRoleByRoleId(request.getRoleId());
        if (RoleOptional.isPresent())
        {
            throw new IllegalStateException("RoleID already Exist");
        }

        Date currentDate = new Date(new java.util.Date().getTime());

        Role role = new Role();
        role.setRoleId(request.getRoleId());
        role.setRoleName(request.getRoleName());
        role.setRoleState(request.getRoleState());
        role.setCreatedDate(currentDate);
        role.setOrgName(request.getOrgName());


        roleRepository.save(role);
    }

    public List<Role> findRoleWithSorting(String field, Sort.Direction direction) {
        Sort sort = Sort.by(direction, field);
        if (direction == Sort.Direction.DESC) {
            sort = sort.descending();
        } else if (direction == Sort.Direction.ASC){
            sort = sort.ascending();
        }
        return roleRepository.findAll(sort);
    }


    public void deleteRole(String RoleId) throws RoleNotFoundException {
        boolean exists = roleRepository.existsByRoleId(RoleId);
        if (!exists)
        {
            throw new RoleNotFoundException(
                    "Role with RoleId: "+RoleId+" does not exists");
        }
        roleRepository.deleteByRoleId(RoleId);
    }

    public void updateRole(String RoleID,Role updatedRole)
    {
        Role role = roleRepository.findRoleByRoleId(RoleID).orElseThrow(
                () -> new IllegalStateException(
                        "Role with RoleID "+RoleID+" does not exist")
        );

        String name = updatedRole.getRoleName();
        if (name!= null)
        {
            // Validate that the roleName is not empty and contains only letters, underscores, and spaces
            if (name.isEmpty() || !name.matches("^[a-zA-Z_ ]+$")) {
                throw new IllegalArgumentException("RoleName must not be empty and must contain only letters, underscores, and spaces.");
            }
            role.setRoleName(name);
        }

        Boolean state = updatedRole.getRoleState();
        // Set a default value for roleState if it is null
//        role.setRoleState(Objects.requireNonNullElse(state, false));
        role.setRoleState(state != null ? state : false);
        if (updatedRole.getOrgName()!= null) {
            role.setOrgName(updatedRole.getOrgName());
        }


        roleRepository.save(role);

    }
    public Page<Role> findRoleWithPagination(int offset, int pageSize) {
        return roleRepository.findAll(PageRequest.of(offset, pageSize));
    }

    public List<Role> listAll(String keyword) {
        if (keyword != null) {
            keyword = keyword.trim();
            if (!keyword.isEmpty()) {
                return roleRepository.search(keyword.toLowerCase());
            }
        }
        return roleRepository.findAll();
    }

//    @Override
//    protected Page modifyResultsIfRequired(Page page) {
//        return page;
//    }
//
//    @Override
//    protected BooleanExpression createBooleanExpression(String property, String operator, String value) {
//        return null;
//    }

//    public PageWrapper processPageRequest(com.Squadra.Role.entity.PageRequest request) {
//        //BooleanExpression ex = NativeQueryNonScalarRootReturn
//        return processPageRequest(request,roleRepository);
  //  }
}
