package com.Squadra.Role.repository;

import com.Squadra.Role.entity.Role;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long>
//        BaseRepository<Role,String>, PagingAndSortingRepository<Role,String>, QuerydslPredicateExecutor<Role>
{
     List<Role> findAll(Specification<Role> spec);

    @Query("SELECT p FROM Role p WHERE LOWER(p.roleName) LIKE %?1%"
            + " OR LOWER( p.orgName) LIKE %?1%"
            + " OR LOWER( p.roleId)LIKE %?1%"
            + " OR LOWER(CONCAT(p.roleState, ''))LIKE %?1%"
            + " OR LOWER(CONCAT(p.createdDate, '')) LIKE %?1%"
    )
    List<Role> search(String keyword);

    Optional<Role> findRoleByRoleId(String RoleId);

    List<Role> findAllByOrderByIdDesc();

    void deleteByRoleId(String roleId);

    boolean existsByRoleId(String roleId);
}
