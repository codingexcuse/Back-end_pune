// package com.Squadra.Role;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class RoleApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
